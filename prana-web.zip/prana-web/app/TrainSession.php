<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class TrainSession extends Model
{
    use Notifiable;

    protected $table = 'train_sessions';

    protected $fillable = [
        'user_id', 'session_started_at', 'session_duration', 'train_type', 'wear_position', 'train_method', 'upright_posture_score', 'slouches', 'slouches_at', 'breathing_pattern', 'total_breaths', 'mindful_breathing_score', 'breaths_list', 'avg_rr'
    ];

    protected $hidden = [
        'created_at', 'updated_at'
    ];

    private $rules = array();
}
