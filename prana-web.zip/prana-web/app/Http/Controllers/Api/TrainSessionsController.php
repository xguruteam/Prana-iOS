<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\TrainSession;

class TrainSessionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $user = $request->user();

        $train_sessions = TrainSession::where('user_id', $user['id'])->get();

        $summary = '';
        $summary_breathing_duration = 0;
        $summary_breathing_goal = 0;
        $summary_mindful_breaths_s = 0;
        $summary_mindful_breathing_mins = 0;
        $cnt = 0;
        $total_avg_rr = 0;
        $summary_avg_trainingPR = 0;
        $summary_posture_duration = 0;
        $summary_posture_goal = 0;
        $summary_upright_posture_s = 0;
        $summary_upright_posture_mins = 0;

        foreach ($train_sessions as $session) {
            // $session['slouches_at'] = json_decode($session['slouches_at']);
            // $session['breaths_list'] = json_decode($session['breaths_list']);
            $session['slouches_at'] = "";
            $session['breaths_list'] = "";
            // 0: training ... 1: tracking

            $train_type = '';
            switch ($session['train_type']) {
                case 'Breathing':
                    $train_type = 'Breathing Only, ';
                    $summary_breathing_duration += $session['session_duration'];
                    $summary_mindful_breathing_mins += $session['session_duration'] * $session['mindful_breathing_score'] / 100;
                    break;
                case 'Posture':
                    $train_type = 'Posture Only, ';
                    $summary_posture_duration += $session['session_duration'];
                    $summary_upright_posture_mins += $session['session_duration'] * $session['upright_posture_score'] / 100;
                    break;
                case 'BreathingPosture':
                    $train_type = 'Breathing with Posture, ';
                    $summary_breathing_duration += $session['session_duration'];
                    $summary_posture_duration += $session['session_duration'];
                    $summary_mindful_breathing_mins += $session['session_duration'] * $session['mindful_breathing_score'] / 100;
                    $summary_upright_posture_mins += $session['session_duration'] * $session['upright_posture_score'] / 100;
                    break;
            }
            $desc = ($session['type'] == '0' ? "Training: " . $train_type : "Passive Tranking: ")
                . $session['session_duration'] . " Mins completed, "
                . (($session['train_type'] == 'Breathing' || $session['train_type'] == 'BreathingPosture') ? " Mindful Breaths: " . round($session['mindful_breathing_score'], 1) . " % Avg. RR: " . round($session['avg_rr'], 1) . ", Custom Breathing, " : "")
                . (($session['train_type'] == 'Posture' || $session['train_type'] == 'BreathingPosture') ? " Upright posture: " . round($session['upright_posture_score'], 1) . ", Slouches: " . $session['slouches'] . ", " : "")
                . (($session['wear_position'] == 0) ? "Upper Chest" : "Lower Back");

            $session['description'] = $desc;

            $cnt++;
            $total_avg_rr += $session['avg_rr'];
        }

        $summary_mindful_breaths_s = $summary_mindful_breathing_mins / $summary_breathing_duration * 100;
        $summary_upright_posture_s = $summary_upright_posture_mins / $summary_posture_duration * 100;

        $summary = round($summary_breathing_duration, 1) . " Mins\n"
            . "5 Mins\n"
            . round($summary_mindful_breaths_s, 1) . " %\n"
            . round($summary_mindful_breathing_mins, 1) . " Mins\n"
            . round($total_avg_rr / $cnt, 1) . "\n\n"
            . round($summary_posture_duration, 1) . " Mins\n"
            . "10 Mins\n"
            . round($summary_upright_posture_s, 1) . " %\n"
            . round($summary_upright_posture_mins, 1) . " Mins";

        $res = array();
        $res['data'] = $train_sessions;
        $res['summary'] = $summary;
        $res['count'] = sizeof($train_sessions);

        return response()->json($res);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();

        $user = $request->user();

        $validator = Validator::make($data, [
            'session_started_at' => 'required',
            'session_duration' => 'required',
            'train_type' => 'required',
            'wear_position' => 'required|numeric',
            'train_method' => 'required',
            'upright_posture_score' => 'required',
            'slouches' => 'required|numeric',
            // 'slouches_at' => 'required',
            'breathing_pattern' => 'required|numeric',
            'total_breaths' => 'required|numeric',
            'mindful_breathing_score' => 'required',
            // 'breaths_list' => 'required',
            'avg_rr' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()->all()], 422);
        }

        $session_started_at = \Carbon\Carbon::createFromFormat('m-d-Y H:i:s', substr($request->session_started_at, 0, 19));

        $train_session = new TrainSession();

        $train_session->user_id = $user->id;
        $train_session->session_started_at = $session_started_at;
        $train_session->session_duration = $data['session_duration'];
        $train_session->type = $data['type'];
        $train_session->train_type = $data['train_type'];
        $train_session->wear_position = $data['wear_position'];
        $train_session->train_method = $data['train_method'];
        $train_session->upright_posture_score = $data['upright_posture_score'];
        $train_session->slouches = $data['slouches'];
        $train_session->slouches_at = "";
        $train_session->breathing_pattern = $data['breathing_pattern'];
        $train_session->total_breaths = $data['total_breaths'];
        $train_session->mindful_breathing_score = $data['mindful_breathing_score'];
        $train_session->breaths_list = "";
        $train_session->avg_rr = $data['avg_rr'];

        $train_session->save();

        return response()->json(['message' => 'Train session saved'], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
