<?php

namespace App\Http\Controllers\Api;

use App\Session;
use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class SessionController extends Controller
{
    /**
     * List of session data.
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function fetch(Request $request)
    {
        try {
            $this->validate($request, [
                'uuid' => 'nullable|array'
            ]);
            $uuid = $request->uuid;
            $resp = Session::with([])->where('user_id', '=', Auth::id())->when($uuid, function ($q) use ($uuid) {
                $q->whereIn('uuid', $uuid);
            })->select('uuid', 'type', 'time', 'data')->get();
            return response()->json($resp);
        } catch (ValidationException $exception) {
            return response()->json(['errors' => $exception->errors()], 422);
        } catch (Exception $e) {
            return response()->json(['message' => 'Something went wrong'], 400);
        }
    }

    /**
     * Store new sessions data
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function upload(Request $request)
    {
        try {
            $this->validate($request, [
                'sessions' => 'required|array|min:1'
            ]);
            $sessions = $request->sessions;
            $resp = [];
            foreach ($sessions as $session) {
                $sessionData = new Session([
                    'user_id' => Auth::id(),
                    'uuid' => $session['uuid'],
                    'type' => $session['type'],
                    'time' => $session['time'],
                    'data' => $session['data']
                ]);
                $sessionData->save();
                array_push($resp, $sessionData->uuid);
            }
            return response()->json($resp);
        } catch (ValidationException $exception) {
            return response()->json(['errors' => $exception->errors()], 422);
        } catch (Exception $e) {
            return response()->json(['message' => 'Something went wrong'], 400);
        }
    }
}
