<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Str;
use Illuminate\Support\Facades\DB;


class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $birth_date = \Carbon\Carbon::createFromFormat('d/m/Y', '01/01/1990');

        DB::table('users')->insert([
            'first_name' => 'prana',
            'last_name' => 'admin',
            'email' => 'admin@prana.com',
            'password'=> bcrypt('PranaAdmin'),
            'birth_date' => $birth_date,
            'gender' => 'male',
            'is_admin' => true
        ]);
    }
}
