<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTrainSessionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('train_sessions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->datetime('session_started_at');
            $table->integer('session_duration');
            $table->integer('type')->default(0);
            $table->string('train_type', 20);
            $table->integer('wear_position');
            $table->string('train_method', 20);
            $table->float('upright_posture_score');
            $table->integer('slouches');
            $table->text('slouches_at');
            $table->integer('breathing_pattern');
            $table->integer('total_breaths');
            $table->float('mindful_breathing_score');
            $table->text('breaths_list');
            $table->float('avg_rr');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('train_sessions');
    }
}
