<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return response()->json($request->user());
});

Route::resource('trainsessions', 'Api\TrainSessionsController')->middleware('auth:api');

Route::post('register', 'Api\UsersController@register');
Route::post('login', 'Api\UsersController@login');
Route::get('profile', 'Api\UsersController@profile')->middleware('auth:api');
Route::post('logout', 'Api\UsersController@logout')->middleware('auth:api');
Route::group([
    'namespace' => 'Api',
    'prefix' => 'password'
], function () {
    Route::post('create', 'PasswordResetController@create');
    Route::get('find/{token}', 'PasswordResetController@find');
    Route::post('reset', 'PasswordResetController@reset');
});
Route::group(['namespace' => 'Api'], function () {
    Route::post('session/upload', 'SessionController@upload')->middleware('auth:api');
    Route::post('session/fetch', 'SessionController@fetch')->middleware('auth:api');
});
